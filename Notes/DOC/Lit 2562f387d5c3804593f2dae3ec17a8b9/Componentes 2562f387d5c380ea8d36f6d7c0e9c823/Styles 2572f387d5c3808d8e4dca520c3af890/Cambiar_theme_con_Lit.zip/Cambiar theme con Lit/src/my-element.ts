import { LitElement, css, html } from "lit";
import { customElement, property } from "lit/decorators.js";
type Theme = "light" | "dark";
@customElement("list-map-demo")
export class ListMapDemo extends LitElement {
  static styles = css`
    button {
      color: var(--button-text-color, black);
      background: var(--button-background-color, white);
      border-radius: 4px;
      padding: 10px;
      margin: 8px;
    }
  `;
  @property({ reflect: true })
  theme: Theme = "light";

  toggleTheme() {
    if (this.theme === "light") {
      this.theme = "dark";
      document.documentElement.style.setProperty(
        "--background-color",
        "var(--background-color-dark)"
      );
      document.documentElement.style.setProperty(
        "--button-text-color",
        "var(--button-text-color-dark)"
      );
      document.documentElement.style.setProperty(
        "--button-background-color",
        "var(--button-background-color-dark)"
      );
    } else {
      this.theme = "light";
      document.documentElement.style.setProperty(
        "--background-color",
        "var(--background-color-light)"
      );
      document.documentElement.style.setProperty(
        "--button-text-color",
        "var(--button-text-color-light)"
      );
      document.documentElement.style.setProperty(
        "--button-background-color",
        "var(--button-background-color-light)"
      );
    }
  }

  render() {
    return html` <button @click=${this.toggleTheme}>Cambiar tema</button> `;
  }
}
